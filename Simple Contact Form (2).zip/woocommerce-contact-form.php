<?php
/*
Plugin Name: Simple Contact Form
Plugin URI: https://yourwebsite.com
Description: Adds a simple contact form to the website and stores submissions in the WordPress database.
Version: 1.0
Author: Shagun Mishra-Ace Assured
Author URI: https://yourwebsite.com
License: GPL2
*/

// --- Activation Hook to Create Database Table ---
register_activation_hook(__FILE__, 'create_contact_form_table');

function create_contact_form_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id INT(11) NOT NULL AUTO_INCREMENT,
        full_name VARCHAR(255) NOT NULL,
        phone_number VARCHAR(20) NOT NULL,
        email VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        submission_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// --- Add "Contact Us" Form via Shortcode ---
function add_contact_form()
{
    ob_start(); // Start output buffering
    ?>
    <div class="contact-form-container">
        <h2>Request Quote</h2>
        <form id="contact-form">
            <label for="full-name">Full Name:</label>
            <input type="text" id="full-name" name="full_name" required>

            <label for="phone-number">Phone Number:</label>
            <input type="text" id="phone-number" name="phone_number" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Submit</button>
        </form>
    </div>
    <?php
    return ob_get_clean(); // Return the buffered content
}
add_shortcode('woocommerce-contact-form', 'add_contact_form');

// --- Handle Form Submission and Store Data in Database ---
// --- Handle Form Submission and Store Data in Database ---
function handle_contact_form_submission()
{
    global $wpdb;

    if (!empty($_POST['form_data'])) {
        parse_str($_POST['form_data'], $form_data);

        $table_name = $wpdb->prefix . 'contact_form_submissions';
        $wpdb->insert(
            $table_name,
            [
                'full_name' => sanitize_text_field($form_data['full_name']),
                'phone_number' => sanitize_text_field($form_data['phone_number']),
                'email' => sanitize_email($form_data['email']),
                'message' => sanitize_textarea_field($form_data['message']),
            ]
        );

        // Send confirmation email to the customer
        $customer_email = sanitize_email($form_data['email']);
        $subject = "Thank You for Your Quote Request - Aniga Jewellers";
        $message = "
    <div style='font-family: Arial, sans-serif; background-color: #5C9EAD21; padding: 20px;'>
        <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden;'>
            <!-- Banner Section -->
            <div style='text-align: center; background-color: #333333; padding: 20px;'>
                <img src='https://mistyrose-rail-299769.hostingersite.com/wp-content/uploads/2024/12/Group-1.png' alt='Aniga Jewellers Logo' style='max-height: 60px;'>
                <h1 style='color: #ffffff; margin: 0; font-size: 24px;'>Thank You for Your Inquiry</h1>
            </div>

            <!-- Main Content Section -->
            <div style='padding: 20px;'>
                <p style='font-size: 16px; color: #333333;'>
                    Dear <strong>" . esc_html($form_data['full_name']) . "</strong>,
                </p>
                <p style='font-size: 14px; color: #555555;'>
                    Thank you for reaching out to <strong>Aniga Jewellers</strong>. We have received your request for a quote, and our team will get back to you shortly. Here are the details you provided:
                </p>
                <table style='width: 100%; border-collapse: collapse; margin-top: 15px;'>
                    <tr>
                        <td style='padding: 8px; font-size: 14px; color: #333333; background-color: #f4f4f4;'><strong>Full Name:</strong></td>
                        <td style='padding: 8px; font-size: 14px; color: #333333;'>" . esc_html($form_data['full_name']) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px; font-size: 14px; color: #333333; background-color: #f4f4f4;'><strong>Phone Number:</strong></td>
                        <td style='padding: 8px; font-size: 14px; color: #333333;'>" . esc_html($form_data['phone_number']) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px; font-size: 14px; color: #333333; background-color: #f4f4f4;'><strong>Email:</strong></td>
                        <td style='padding: 8px; font-size: 14px; color: #333333;'>" . esc_html($form_data['email']) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 8px; font-size: 14px; color: #333333; background-color: #f4f4f4;'><strong>Message:</strong></td>
                        <td style='padding: 8px; font-size: 14px; color: #333333;'>" . nl2br(esc_html($form_data['message'])) . "</td>
                    </tr>
                </table>
                <p style='font-size: 14px; color: #555555; margin-top: 20px;'>
                    If you have any further questions, please feel free to contact us.
                </p>
            </div>

            <!-- Footer Section -->
            <div style='background-color: #333333; text-align: center; padding: 20px;'>
                <p style='font-size: 12px; color: #ffffff; margin: 0;'>© " . date('Y') . " Aniga Jewellers. All rights reserved.</p>
                <p style='font-size: 12px; color: #ffffff; margin: 0;'>Follow us on:</p>
                <p style='margin: 10px 0;'>
                    <a href='#' style='text-decoration: none; color: #ffffff; margin-right: 10px;'>Facebook</a> |
                    <a href='https://www.instagram.com/anigalifestyle/?hl=en' style='text-decoration: none; color: #ffffff; margin-left: 10px;'>Instagram</a>
                </p>
            </div>
        </div>
    </div>
";

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Aniga Jewellers <shagun@aceassured.com>',
        ];

        wp_mail($customer_email, $subject, $message, $headers);

        wp_send_json_success('Your contact form has been submitted successfully! A confirmation email has been sent to your email address.');
    } else {
        wp_send_json_error('Invalid form submission.');
    }

    wp_die();
}
add_action('wp_ajax_handle_contact_form', 'handle_contact_form_submission');
add_action('wp_ajax_nopriv_handle_contact_form', 'handle_contact_form_submission');


// --- Add Admin Menu for Contact Form Submissions ---
function add_contact_form_menu()
{
    add_menu_page(
        'Contact Form Submissions',
        'Aniga Customer Enquiry',
        'manage_options',
        'contact-form-submissions',
        'display_contact_form_submissions',
        'dashicons-email-alt',
        26
    );
}
add_action('admin_menu', 'add_contact_form_menu');

// --- Handle Delete Request ---
function handle_contact_form_delete()
{
    if (isset($_GET['delete_submission']) && is_numeric($_GET['delete_submission'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'contact_form_submissions';
        $submission_id = intval($_GET['delete_submission']);
        $wpdb->delete($table_name, ['id' => $submission_id]);
        wp_redirect(admin_url('admin.php?page=contact-form-submissions'));
        exit;
    }
}
add_action('admin_init', 'handle_contact_form_delete');

// --- Display Stored Submissions in Admin Panel ---
function display_contact_form_submissions()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form_submissions';
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submission_date DESC");

    echo '<div class="wrap"><h1>Contact Form Submissions</h1>';
    echo '<table class="widefat fixed striped">';
    echo '<thead><tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
            <th>Actions</th>
        </tr></thead>';
    echo '<tbody>';

    foreach ($results as $row) {
        $delete_url = esc_url(add_query_arg(['delete_submission' => $row->id], admin_url('admin.php?page=contact-form-submissions')));
        echo '<tr>';
        echo '<td>' . esc_html($row->id) . '</td>';
        echo '<td>' . esc_html($row->full_name) . '</td>';
        echo '<td>' . esc_html($row->phone_number) . '</td>';
        echo '<td>' . esc_html($row->email) . '</td>';
        echo '<td>' . esc_html($row->message) . '</td>';
        echo '<td>' . esc_html($row->submission_date) . '</td>';
        echo '<td>
                <a href="' . $delete_url . '" class="button button-secondary" onclick="return confirm(\'Are you sure you want to delete this submission?\')">Delete</a>
              </td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

// --- Enqueue Scripts and Styles for Form ---
function enqueue_contact_form_scripts()
{
    wp_enqueue_script('jquery');
    wp_add_inline_script('jquery', '
        jQuery(document).ready(function ($) {
            $("#contact-form").on("submit", function (e) {
                e.preventDefault();
                
                // Validate the form
                let isValid = true;
                let errorMessage = "";
                const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
                const phoneRegex = /^[0-9]{10,15}$/; // Adjust length as needed

                const fullName = $("#full-name").val().trim();
                const phoneNumber = $("#phone-number").val().trim();
                const email = $("#email").val().trim();
                const message = $("#message").val().trim();

                if (!fullName) {
                    isValid = false;
                    errorMessage += "Full Name is required.\\n";
                }
                if (!phoneRegex.test(phoneNumber)) {
                    isValid = false;
                    errorMessage += "Phone Number should contain only digits and be 10-15 characters long.\\n";
                }
                if (!emailRegex.test(email)) {
                    isValid = false;
                    errorMessage += "Please enter a valid email address.\\n";
                }
                if (!message) {
                    isValid = false;
                    errorMessage += "Message is required.\\n";
                }

                if (!isValid) {
                    alert(errorMessage);
                    return; // Stop form submission
                }

                // Submit the form
                let $submitButton = $(this).find("button[type=\'submit\']");
                $submitButton.prop("disabled", true).text("Submitting...");

                $.post(contactFormAjax.ajaxurl, {
                    action: "handle_contact_form",
                    form_data: $(this).serialize()
                }, function (response) {
                    alert(response.data);
                    $submitButton.prop("disabled", false).text("Submit");
                    $("#contact-form")[0].reset();
                }).fail(function () {
                    alert("Something went wrong. Please try again.");
                    $submitButton.prop("disabled", false).text("Submit");
                });
            });
        });
    ');
    wp_enqueue_style('contact-form-style', plugin_dir_url(__FILE__) . 'css/contact-form.css');
    wp_localize_script('jquery', 'contactFormAjax', ['ajaxurl' => admin_url('admin-ajax.php')]);
}

add_action('wp_enqueue_scripts', 'enqueue_contact_form_scripts');

